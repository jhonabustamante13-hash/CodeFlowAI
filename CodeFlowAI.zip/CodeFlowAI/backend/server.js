// Backend seguro: la clave vive aquí (variable de entorno), nunca en la app.
// Uso: ANTHROPIC_API_KEY=tu_clave node server.js
import express from "express";
const app = express();
app.use(express.json({ limit: "200kb" }));
app.use((q, s, n) => {
  s.set("Access-Control-Allow-Origin", process.env.ORIGIN || "*");
  s.set("Access-Control-Allow-Headers", "Content-Type");
  if (q.method === "OPTIONS") return s.sendStatus(204);
  n();
});
const hits = new Map();
const SYS = {
  generar: "Eres un programador senior. Genera el código pedido en un solo bloque ``` y una explicación breve en español.",
  modificar: "Modifica el código dado según la petición. Devuelve el código completo en un bloque ``` y resume los cambios en español.",
  corregir: "Analiza el código: lista los errores con línea y causa, explícalos en español y devuelve el código corregido en un bloque ```. No afirmes haberlo ejecutado.",
  explicar: "Explica el código en español: qué hace, cómo funciona, tecnologías y mejoras. Da una explicación sencilla y una avanzada.",
  optimizar: "Optimiza el código (rendimiento, legibilidad, duplicación, malas prácticas). Devuelve el código en un bloque ``` y explica los cambios en español.",
};
app.post("/api/ai", async (q, s) => {
  const now = Date.now(), a = (hits.get(q.ip) || []).filter(t => now - t < 60000);
  if (a.length >= 10) return s.sendStatus(429);
  a.push(now); hits.set(q.ip, a);
  const { task, language, code, prompt } = q.body || {};
  if (!SYS[task]) return s.status(400).json({ error: "tarea inválida" });
  const user = `Lenguaje: ${language}\nPetición: ${prompt || ""}\nCódigo:\n${code || ""}`;
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: process.env.MODEL || "claude-sonnet-5-5", max_tokens: 2500, system: SYS[task], messages: [{ role: "user", content: user }] }),
    });
    if (!r.ok) return s.status(502).json({ error: "upstream " + r.status });
    const d = await r.json();
    s.json({ text: d.content.filter(b => b.type === "text").map(b => b.text).join("\n") });
  } catch { s.status(502).json({ error: "fallo de red" }); }
});
app.listen(process.env.PORT || 8787);
