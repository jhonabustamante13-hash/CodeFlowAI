import { useState } from "react";
import { getApi, setApi } from "../services/storage";
export default function Profile({ projects, toast }: any) {
  const [u, setU] = useState(getApi());
  return (<>
    <h1>Perfil</h1>
    <div className="gl pj"><span>Proyectos guardados<br /><small>{projects.length}</small></span></div>
    <div className="gl box">
      <b>Conexión de IA</b>
      <p className="sub" style={{ margin: 0 }}>Estado: {u ? "Dirección configurada (no verificada)" : "No configurada"}</p>
      <input className="nm" value={u} onChange={e => setU(e.target.value)} placeholder="https://tu-backend.com" />
      <button className="btn" onClick={() => { setApi(u); toast("Dirección guardada"); }}>Guardar</button>
      <p className="sub" style={{ margin: 0, fontSize: 12 }}>Tu clave de la API vive solo en el backend, nunca en la app.</p>
    </div>
  </>);
}
