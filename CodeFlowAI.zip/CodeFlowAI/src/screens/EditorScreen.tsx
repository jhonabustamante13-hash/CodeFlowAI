import { useRef, useState } from "react";
import CodeMirror from "@uiw/react-codemirror";
import { javascript } from "@codemirror/lang-javascript";
import { html } from "@codemirror/lang-html";
import { css } from "@codemirror/lang-css";
import { python } from "@codemirror/lang-python";
import { java } from "@codemirror/lang-java";
import { undo, redo } from "@codemirror/commands";
import { openSearchPanel } from "@codemirror/search";
import { Undo2, Redo2, Search, Save, Download, Play } from "lucide-react";
import { LANGS, EXT } from "../langs";
const ext = (l: string): any[] => l === "javascript" ? [javascript()] : l === "html" ? [html()] : l === "css" ? [css()] : l === "python" ? [python()] : [java()];
export default function EditorScreen({ p, onSave, toast }: any) {
  const [code, setCode] = useState(p.code); const [lang, setLang] = useState(p.lang); const [name, setName] = useState(p.name);
  const [prev, setPrev] = useState(false); const view = useRef<any>(null);
  const dl = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([code], { type: "text/plain" }));
    a.download = name + "." + EXT[lang]; a.click(); toast("Descarga iniciada");
  };
  return (<>
    <h1>Editor</h1>
    <input className="nm" value={name} onChange={e => setName(e.target.value)} />
    <div className="tb">
      <select value={lang} onChange={e => setLang(e.target.value)}>{LANGS.map(l => <option key={l}>{l}</option>)}</select>
      <button className="chip" onClick={() => view.current && undo(view.current)}><Undo2 size={16} /></button>
      <button className="chip" onClick={() => view.current && redo(view.current)}><Redo2 size={16} /></button>
      <button className="chip" onClick={() => view.current && openSearchPanel(view.current)}><Search size={16} /></button>
      <button className="chip" onClick={() => onSave({ ...p, name, lang, code })}><Save size={16} /></button>
      <button className="chip" onClick={dl}><Download size={16} /></button>
      {lang === "html" && <button className="chip" onClick={() => setPrev(!prev)}><Play size={16} /></button>}
    </div>
    <div className="gl cm"><CodeMirror value={code} height="320px" theme="dark" extensions={ext(lang)} onChange={setCode}
      onCreateEditor={v => (view.current = v)} basicSetup={{ lineNumbers: true }} /></div>
    {prev && lang === "html" && <iframe className="gl pv" sandbox="allow-scripts" srcDoc={code} title="Vista previa" />}
  </>);
}
