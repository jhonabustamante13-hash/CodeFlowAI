import { useState } from "react";
import { Copy, Save } from "lucide-react";
import Typewriter from "../components/Typewriter";
import { askAI, extractCode, NO_API_MSG } from "../services/ai";
import { LANGS } from "../langs";
import { uid } from "../services/storage";
export default function Create({ save, toast, openIt }: any) {
  const [prompt, setPrompt] = useState(""); const [lang, setLang] = useState("javascript");
  const [res, setRes] = useState(""); const [mod, setMod] = useState(""); const [busy, setBusy] = useState(false);
  const run = async (task: string, code: string, p: string) => {
    if (!p.trim()) return toast("Escribe qué quieres crear");
    setBusy(true);
    try { setRes(await askAI(task, lang, code, p)); }
    catch (e: any) { toast(e.message === "NO_API" ? NO_API_MSG : e.message); }
    setBusy(false);
  };
  const code = extractCode(res) || res;
  return (<>
    <h1>Crear con IA</h1><p className="sub">Describe lo que quieres construir.</p>
    <div className="gl box">
      <textarea rows={4} value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Ej: Créame una calculadora moderna para Android" />
      <select value={lang} onChange={e => setLang(e.target.value)}>{LANGS.map(l => <option key={l}>{l}</option>)}</select>
      <button className="btn" disabled={busy} onClick={() => run("generar", "", prompt)}>{busy ? "Pensando…" : "Generar código"}</button>
    </div>
    {busy && <div className="sub"><span className="ld" /><span className="ld" /><span className="ld" /></div>}
    {res && <>
      <Typewriter text={res} />
      <div className="tb">
        <button className="chip" onClick={() => { navigator.clipboard?.writeText(code); toast("Copiado"); }}><Copy size={14} /> Copiar</button>
        <button className="chip" onClick={() => { const p = { id: uid(), name: prompt.slice(0, 28) || "Proyecto", lang, code, updated: 0 }; save(p); openIt({ ...p, updated: Date.now() }); }}><Save size={14} /> Guardar y abrir</button>
      </div>
      <div className="gl box">
        <textarea rows={2} value={mod} onChange={e => setMod(e.target.value)} placeholder="Pide una modificación…" />
        <button className="btn" disabled={busy} onClick={() => run("modificar", code, mod)}>Modificar</button>
      </div>
    </>}
  </>);
}
