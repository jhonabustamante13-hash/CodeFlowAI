import { motion } from "framer-motion";
import { Sparkles, Code2, Bug, Pencil, Trash2 } from "lucide-react";
export default function Home({ go, projects, open, del, rename }: any) {
  return (<>
    <div className="gl hero">
      <motion.div className="logo" animate={{ scale: [1, 1.06, 1] }} transition={{ repeat: Infinity, duration: 3 }}>&lt;/&gt;</motion.div>
      <h1>CodeFlow AI</h1>
      <p className="sub">Tu creatividad. Tu código. Tu inteligencia.</p>
      <motion.button whileTap={{ scale: .93 }} className="btn" onClick={() => go(1)}>Comenzar</motion.button>
    </div>
    <div className="row">
      <div className="gl qa" onClick={() => go(1)}><Sparkles />Generador</div>
      <div className="gl qa" onClick={() => go(2)}><Code2 />Editor</div>
      <div className="gl qa" onClick={() => go(3)}><Bug />Corrector</div>
    </div>
    <h3>Proyectos recientes</h3>
    {projects.length === 0 && <div className="gl pj"><span>Aún no tienes proyectos. Crea uno en la pestaña Crear o guarda desde el Editor.</span></div>}
    {projects.map((p: any) => (
      <div className="gl pj" key={p.id}>
        <span onClick={() => open(p)} style={{ flex: 1 }}>{p.name}<br /><small>{p.lang} · {new Date(p.updated).toLocaleDateString("es")}</small></span>
        <button className="ib" onClick={() => { const n = prompt("Nuevo nombre", p.name); if (n) rename(p, n); }}><Pencil size={18} /></button>
        <button className="ib" onClick={() => { if (confirm("¿Eliminar este proyecto?")) del(p.id); }}><Trash2 size={18} /></button>
      </div>
    ))}
  </>);
}
