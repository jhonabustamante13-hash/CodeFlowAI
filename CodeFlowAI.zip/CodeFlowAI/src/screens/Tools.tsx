import { useState } from "react";
import { Bug, BookOpen, Zap } from "lucide-react";
import Typewriter from "../components/Typewriter";
import { askAI, extractCode, NO_API_MSG } from "../services/ai";
const T = [["corregir", "Corregir", Bug], ["explicar", "Explicar", BookOpen], ["optimizar", "Optimizar", Zap]] as const;
export default function Tools({ cur, onApply, toast }: any) {
  const [mode, setMode] = useState("corregir"); const [code, setCode] = useState(cur.code);
  const [res, setRes] = useState(""); const [busy, setBusy] = useState(false);
  const run = async () => {
    if (!code.trim()) return toast("Pega o escribe código primero");
    setBusy(true); setRes("");
    try { setRes(await askAI(mode, cur.lang, code, "")); }
    catch (e: any) { toast(e.message === "NO_API" ? NO_API_MSG : e.message); }
    setBusy(false);
  };
  const fixed = mode !== "explicar" ? extractCode(res) : "";
  return (<>
    <h1>Herramientas</h1>
    <div className="tb">{T.map(([k, n, I]) => <button key={k} className={"chip" + (mode === k ? " on" : "")} onClick={() => { setMode(k); setRes(""); }}><I size={14} /> {n}</button>)}</div>
    <div className="gl box">
      <textarea rows={8} value={code} onChange={e => setCode(e.target.value)} placeholder="Pega tu código aquí" style={{ fontFamily: "monospace" }} />
      <button className="btn" disabled={busy} onClick={run}>{busy ? "Analizando…" : "Analizar"}</button>
    </div>
    {busy && <div className="sub"><span className="ld" /><span className="ld" /><span className="ld" /></div>}
    {res && <Typewriter text={res} />}
    {fixed && <>
      <h3>Antes</h3><pre className="out">{code}</pre>
      <h3>Después (sugerido por la IA, no ejecutado ni probado)</h3><pre className="out">{fixed}</pre>
      <button className="btn" onClick={() => onApply(fixed)}>Aplicar en el editor</button>
    </>}
  </>);
}
