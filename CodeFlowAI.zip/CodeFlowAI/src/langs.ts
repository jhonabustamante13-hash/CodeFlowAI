export const LANGS = ["javascript", "html", "css", "python", "java", "kotlin"];
export const EXT: Record<string, string> = { javascript: "js", html: "html", css: "css", python: "py", java: "java", kotlin: "kt" };
