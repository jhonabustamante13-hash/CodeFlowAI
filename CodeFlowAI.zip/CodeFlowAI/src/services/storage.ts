export type Project = { id: string; name: string; lang: string; code: string; updated: number };
const K = "cfai_projects";
export const uid = () => Math.random().toString(36).slice(2, 10);
export const load = (): Project[] => { try { return JSON.parse(localStorage.getItem(K) || "[]"); } catch { return []; } };
const save = (p: Project[]) => localStorage.setItem(K, JSON.stringify(p));
export function upsert(p: Project) { const a = load().filter(x => x.id !== p.id); a.unshift({ ...p, updated: Date.now() }); save(a); return a; }
export function remove(id: string) { const a = load().filter(x => x.id !== id); save(a); return a; }
export const getApi = (): string => localStorage.getItem("cfai_api") || (import.meta as any).env?.VITE_API_URL || "";
export const setApi = (u: string) => localStorage.setItem("cfai_api", u.trim());
