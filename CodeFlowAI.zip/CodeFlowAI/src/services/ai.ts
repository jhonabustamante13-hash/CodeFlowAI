import { getApi } from "./storage";
let last = 0;
export async function askAI(task: string, language: string, code: string, prompt: string): Promise<string> {
  const base = getApi();
  if (!base) throw new Error("NO_API");
  if (Date.now() - last < 3000) throw new Error("Espera unos segundos entre solicitudes.");
  last = Date.now();
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), 60000);
  try {
    const r = await fetch(base.replace(/\/$/, "") + "/api/ai", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ task, language, code, prompt }), signal: c.signal });
    if (r.status === 429) throw new Error("Demasiadas solicitudes. Intenta más tarde.");
    if (!r.ok) throw new Error("El servidor respondió con error " + r.status);
    const d = await r.json();
    return d.text || "";
  } catch (e: any) {
    if (e.name === "AbortError") throw new Error("La solicitud tardó demasiado.");
    throw e;
  } finally { clearTimeout(t); }
}
export const extractCode = (t: string) => { const m = t.match(/```[\w+-]*\n([\s\S]*?)```/); return m ? m[1].trim() : ""; };
export const NO_API_MSG = "IA no configurada. Ve a Perfil y escribe la dirección de tu backend. Sin eso no se genera nada.";
