import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Home as HomeI, Sparkles, Code2, Wrench, User } from "lucide-react";
import Particles from "./components/Particles";
import Home from "./screens/Home";
import Create from "./screens/Create";
import EditorScreen from "./screens/EditorScreen";
import Tools from "./screens/Tools";
import Profile from "./screens/Profile";
import { Project, load, upsert, remove, uid } from "./services/storage";

const NAV = [["Inicio", HomeI], ["Crear", Sparkles], ["Editor", Code2], ["Herramientas", Wrench], ["Perfil", User]] as const;
const blank = (): Project => ({ id: uid(), name: "Sin título", lang: "javascript", code: "", updated: 0 });

export default function App() {
  const [tab, setTab] = useState(0);
  const [projects, setProjects] = useState<Project[]>(load());
  const [cur, setCur] = useState<Project>(projects[0] || blank());
  const [msg, setMsg] = useState("");
  const toast = (m: string) => { setMsg(m); setTimeout(() => setMsg(""), 2600); };
  const save = (p: Project) => { setProjects(upsert(p)); setCur({ ...p, updated: Date.now() }); };
  const open = (p: Project) => { setCur(p); setTab(2); };
  const del = (id: string) => { setProjects(remove(id)); toast("Proyecto eliminado"); };
  const screens = [
    <Home go={setTab} projects={projects} open={open} del={del} rename={(p: Project, n: string) => save({ ...p, name: n })} />,
    <Create save={(p: Project) => { save(p); toast("Proyecto guardado"); }} toast={toast} openIt={open} />,
    <EditorScreen key={cur.id + cur.updated} p={cur} onSave={(p: Project) => { save(p); toast("Guardado"); }} toast={toast} />,
    <Tools cur={cur} onApply={(code: string) => { save({ ...cur, code }); setTab(2); toast("Corrección aplicada"); }} toast={toast} />,
    <Profile projects={projects} toast={toast} />,
  ];
  return (
    <div className="app">
      <Particles /><div className="glow g1" /><div className="glow g2" />
      <div className="main">
        <AnimatePresence mode="wait">
          <motion.div key={tab} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: .25 }}>
            {screens[tab]}
          </motion.div>
        </AnimatePresence>
      </div>
      {msg && <div className="toast gl">{msg}</div>}
      <nav className="nav gl">
        {NAV.map(([n, I], i) => (
          <motion.button whileTap={{ scale: .88 }} key={n} className={"nv" + (tab === i ? " on" : "")} onClick={() => setTab(i)}>
            <I size={20} />{n}
          </motion.button>
        ))}
      </nav>
    </div>
  );
}
